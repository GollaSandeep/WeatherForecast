﻿namespace WeatherForecast.Model
{
    public class WeatherInformation
    {
        public string Name { get; set; }

        public double Temperature { get; set; }

        public int Index { get; set; }
    }
}
