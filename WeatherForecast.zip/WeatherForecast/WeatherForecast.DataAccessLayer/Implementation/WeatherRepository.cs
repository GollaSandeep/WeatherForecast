﻿using WeatherForecast.DataAccessLayer.Interface;
using WeatherForecast.Model;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;
using WeatherForecast.DataAccessLayer.Models;

namespace WeatherForecast.DataAccessLayer.Implementation
{
    public class WeatherRepository : IWeatherRepository
    {
       
        public async Task<WeatherInformation> GetWeather(string cityName)
        {
            HttpClient client = new HttpClient();
            HttpResponseMessage response = await client.GetAsync($"https://openweathermap.org/data/2.5/weather?q={cityName}&appid=439d4b804bc8187953eb36d2a8c26a02");
            
            response.EnsureSuccessStatusCode();
            
            string responseBody = await response.Content.ReadAsStringAsync();
            
            var result = JsonConvert.DeserializeObject<Root>(responseBody);

            var weatherInformation = new WeatherInformation
            {
               Name = result.name,
               Temperature = result.main.temp
            };

            return weatherInformation;
        }
    }
}
