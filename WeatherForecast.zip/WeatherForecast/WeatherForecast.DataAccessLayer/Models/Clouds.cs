﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WeatherForecast.DataAccessLayer.Models
{
    public class Clouds
    {
        public int all { get; set; }

    }
}
