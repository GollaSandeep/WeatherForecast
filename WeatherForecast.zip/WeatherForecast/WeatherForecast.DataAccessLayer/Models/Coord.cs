﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WeatherForecast.DataAccessLayer.Model
{
    public class Coord
    {
        public double lon { get; set; }
        public double lat { get; set; }

    }
}
