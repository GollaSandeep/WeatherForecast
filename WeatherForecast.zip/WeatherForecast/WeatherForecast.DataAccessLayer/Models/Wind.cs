﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WeatherForecast.DataAccessLayer.Models
{
    public class Wind
    {
        public double speed { get; set; }
        public int deg { get; set; }

    }
}
