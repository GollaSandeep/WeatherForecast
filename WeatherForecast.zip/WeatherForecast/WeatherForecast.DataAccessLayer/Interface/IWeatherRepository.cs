﻿using System.Threading.Tasks;
using WeatherForecast.Model;

namespace WeatherForecast.DataAccessLayer.Interface
{
    public interface IWeatherRepository
    {
        Task<WeatherInformation> GetWeather(string cityName);
    }
}
