﻿using System.Collections.Generic;
using System.Threading.Tasks;
using WeatherForecast.Model;

namespace WeatherForecast.BusinessLayer.Interface
{
    public interface IWeatherManager
    {
        Task<IEnumerable<WeatherInformation>> GetWeathers(string cities);
    }
}
