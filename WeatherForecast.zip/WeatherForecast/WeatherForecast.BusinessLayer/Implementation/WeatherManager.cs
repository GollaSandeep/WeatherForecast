﻿using System.Collections.Generic;
using System.Threading.Tasks;
using WeatherForecast.BusinessLayer.Interface;
using WeatherForecast.DataAccessLayer.Interface;
using WeatherForecast.Model;

namespace WeatherForecast.BusinessLayer.Implementation
{
    public class WeatherManager : IWeatherManager
    {
        private readonly IWeatherRepository _weatherRepository;
        public WeatherManager(IWeatherRepository weatherRepository)
        {
            _weatherRepository = weatherRepository;
        }

        public async Task<IEnumerable<WeatherInformation>> GetWeathers(string cities)
        {
            var result = new List<WeatherInformation>();
            var citiesArray = cities.Split(',');
            for (int i = 0; i < citiesArray.Length; i++)
            {
                var weatherInfo = await _weatherRepository.GetWeather(citiesArray[i]);

                if (weatherInfo != null)
                {
                    weatherInfo.Index = i + 1;
                    result.Add(weatherInfo);
                }
            }

            return result;
        }
    }

}
