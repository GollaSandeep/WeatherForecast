﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using WeatherForecast.BusinessLayer.Interface;
using WeatherForecast.Model;

namespace WeatherForecast.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private readonly IWeatherManager _weatherManager;
        private readonly ILogger<WeatherForecastController> _logger;
        public WeatherForecastController(IWeatherManager weatherManager, ILogger<WeatherForecastController> logger)
        {
            _weatherManager = weatherManager;
            _logger = logger;
        }

        [HttpGet]
        [Route("temperatures")]
        public async Task<IEnumerable<WeatherInformation>> Get(string cites)
        {
            var result = await _weatherManager.GetWeathers(cites);
            return result.OrderBy(a => a.Temperature);
        }
    }
}
